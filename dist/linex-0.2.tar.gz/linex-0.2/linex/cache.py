from typing import Any

USERS: dict[str, Any] = {}
GROUPS: dict[str, Any] = {}
MESSAGES: dict[str, Any] = {}

# NOTE: don't import models here (would cause an error)
